Version 0.2 - change log
----------------------------------

1. Just run  the rdc.exe file
   You don't need python to run this

2. Fixed bugs - now the app won't accept month number > 12.
3. Corrected spellings and comments
